#ifndef BRICK_H
#define BRICK_H

#include "tools.h"


// Classe de base abstraite pour toutes les briques
class Brick {
public:
    ~Brick() = default; 
    bool check() const;    

    const Square& get_bounds() const { return bounds_; }
    int get_type() const { return type_; }

    int getIndex(){return brick_index;}

protected:  // "protected" permet aux sous-classes d'accéder à bounds_
    Brick(Square s, int type) : bounds_(s), type_(type) {}
    
    Square bounds_; 
    int type_;

    static int brick_index;
};

// --- Sous-classes spécifiques ---

class RainbowBrick : public Brick{
public:
    RainbowBrick(Square s, int hits_points) : Brick(s, 0), hit_points_(hits_points){}
    
    bool check() const;

private:
    int hit_points_;
};

class BallBrick : public Brick{
public:
    BallBrick(Square s) : Brick(s, 1) {}
};

class SplitBrick: public Brick{
public: 
    SplitBrick(Square s) : Brick(s, 2) {}
};

int Brick::brick_index = 0;//!: pas encore de constructeur pour le modifier l'indexe

#endif